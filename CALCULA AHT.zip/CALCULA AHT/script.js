let calls = 0;
let totalTime = 0;
let callStartTime = 0;
let pauseStartTime = 0;
let totalPauseTime = 0;
let isPaused = false;

document.getElementById("startCall").addEventListener("click", function () {
  callStartTime = new Date().getTime();
});

document.getElementById("endCall").addEventListener("click", function () {
  if (callStartTime !== 0) {
    const callEndTime = new Date().getTime();
    const callTime = (callEndTime - callStartTime) / 1000 / 60; // Tempo em minutos
    totalTime += callTime;
    calls++;

    callStartTime = 0;

    updateResults();
  }
});

document.getElementById("startPause").addEventListener("click", function () {
  if (!isPaused) {
    pauseStartTime = new Date().getTime();
    isPaused = true;
  }
});

document.getElementById("endPause").addEventListener("click", function () {
  if (isPaused) {
    const pauseEndTime = new Date().getTime();
    const pauseTime = (pauseEndTime - pauseStartTime) / 1000 / 60; // Tempo em minutos
    totalPauseTime += pauseTime;
    isPaused = false;

    pauseStartTime = 0;

    updateResults();
  }
});

function updateResults() {
  const averageTime = calls !== 0 ? totalTime / calls : 0;
  document.getElementById("result").textContent = `Tempo Médio de Atendimento: ${averageTime.toFixed(2)} minutos por call`;
  document.getElementById("pauseTotal").textContent = `Tempo Total de Pausa: ${totalPauseTime.toFixed(2)} minutos`;
}
